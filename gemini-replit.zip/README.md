# Gemini Chatbot for Replit

Just run `npm install` and `npm start`.
